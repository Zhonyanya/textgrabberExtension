"use strict";
let copiedText = document.getElementById("copiedText");
navigator.clipboard.readText()
  .then(text => {
    copiedText.innerHTML = text;
  })
  .catch(textError => {
    console.error('Не удалось прочитать содержимое буфера обмена: ', textError);
  });
